from distutils.core import setup

setup(name='weather',
      version='1.0',
      classifiers=['Weather'],
      packages=['Project'],
      )
